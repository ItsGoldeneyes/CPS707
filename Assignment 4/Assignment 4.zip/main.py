from frontend import Frontend

if __name__ == "__main__":
    frontend = Frontend()
    frontend.main()